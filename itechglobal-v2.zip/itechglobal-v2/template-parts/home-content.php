<main>
    <section id="home" class="hero">
      <div class="container hero-grid">
        <div class="reveal">
          <span class="eyebrow">Enterprise IT + EDI</span>
          <h1>Modern systems. Stronger connections. Better outcomes.</h1>
          <p>iTech Global helps ambitious organizations modernize infrastructure, connect trading partners, and launch dependable digital platforms without adding unnecessary complexity.</p>
          <div class="actions">
            <a class="btn primary" href="#contact">Start Your Project</a>
            <a class="btn secondary" href="#services">View Services</a>
          </div>
        </div>
        <aside class="hero-card reveal">
          <img class="logo-watermark" src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/itech-mark.png" alt="">
          <div class="hero-visual">
            <img width="800" height="420" decoding="async" fetchpriority="high" alt="Abstract technology network" src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='420' viewBox='0 0 800 420'><defs><linearGradient id='g1' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='%232bb4f1'/><stop offset='100%' stop-color='%2323e0d1'/></linearGradient></defs><rect width='800' height='420' fill='%230f1f33'/><circle cx='130' cy='140' r='90' fill='url(%23g1)' opacity='0.35'/><circle cx='620' cy='90' r='70' fill='url(%23g1)' opacity='0.25'/><circle cx='520' cy='300' r='110' fill='url(%23g1)' opacity='0.2'/><g fill='none' stroke='%23a8d9ff' stroke-width='2' opacity='0.5'><path d='M80 300 L200 220 L320 260 L450 180 L580 220 L700 140'/><path d='M120 110 L260 160 L360 110 L470 140 L620 90'/></g></svg>">
          </div>
          <h2>How We Work</h2>
          <p class="hero-card-copy">A focused, senior-led approach designed for clarity and dependable delivery.</p>
          <div class="hero-metrics">
            <div class="metric"><h3>Clear scope</h3><span>Defined timelines and milestones</span></div>
            <div class="metric"><h3>Secure delivery</h3><span>Built-in quality practices</span></div>
            <div class="metric"><h3>Partner ready</h3><span>Integration-first execution</span></div>
            <div class="metric"><h3>Long-term support</h3><span>Flexible ongoing care</span></div>
          </div>
        </aside>
      </div>
    </section>

    <section class="section" id="services">
      <div class="container">
        <header class="section-head reveal">
          <span class="eyebrow">Services</span>
          <h2>Capabilities that protect uptime and accelerate growth.</h2>
          <p>From EDI integration to cloud modernization, we deliver structured execution with clear outcomes.</p>
        </header>
        <div class="grid3">
          <article class="card reveal">
            <div class="chip">PRO</div>
            <h3>Product &amp; Service Acceleration</h3>
            <p>High-performing, market-ready product development and acceleration.</p>
            <details class="read-more">
              <summary>Read more</summary>
              <div class="read-more-content">
                <p>We help businesses build products that actually work in the real world â€” not just on paper. Whether you're starting with a rough concept or refining an almost-finished software solution, our team rolls up their sleeves and gets to work alongside you. We've been through enough product cycles to know where things slow down, and we've built our process specifically to avoid those bottlenecks.</p>
                <p>Our tools give you a clear picture of how your product is performing â€” how users are responding, whether the market is ready for it, and how far your reach actually extends. That kind of visibility changes how you plan and make decisions. Instead of guessing, you're working with real data, which means fewer costly pivots and a much cleaner path from development to launch.</p>
                <p>On the collaboration side, we've built everything on modern open-source tech that doesn't get in the way. You get video calls, screen sharing, live whiteboarding, and built-in messaging â€” all in one place. Teams of up to 200 people can join sessions, which makes it easy to bring in stakeholders, gather feedback, and move forward without endless back-and-forth email threads. Admins can also record sessions, so nothing important gets lost after a meeting wraps up. And since everything runs on both Android and iOS, your team stays connected whether they're at a desk or on the move.</p>
                <p>The bigger picture here is simple: we help you test, refine, and sharpen your product before it ever hits the market. That means less trial and error, less wasted budget, and a much better shot at landing well with customers. Good products deserve a strong launch â€” and that's exactly what we're here to make happen.</p>
              </div>
            </details>
          </article>
          <article class="card reveal">
            <div class="chip">IT</div>
            <h3>IT Services &amp; Strategy</h3>
            <p>Modernize operations with secure, scalable IT consulting.</p>
            <details class="read-more">
              <summary>Read more</summary>
              <div class="read-more-content">
                <p>Technology doesn't slow down, and neither does the pressure to keep up with it. Businesses today are constantly being asked to do more â€” faster, smarter, and with fewer resources. That's where we come in. Our IT consulting work is built around one core idea: helping your organization get genuinely comfortable with change, not just survive it.</p>
                <p>We're not big fans of unnecessary manual work, and chances are, neither are you. A big part of what we do is identifying where time and money are quietly being wasted and replacing those gaps with smarter, more automated processes. Better accuracy, tighter security, clearer visibility across your operations â€” these aren't nice-to-haves anymore, they're the baseline. And we help you get there without blowing your budget in the process.</p>
                <p>Cloud computing is one of the strongest levers we pull for our clients. Done right, it gives you flexibility without the overhead â€” platforms that grow with you, architecture that doesn't box you in, and performance that actually matches what your business demands. The goal is always to make sure what you're spending translates into something real on the other end.</p>
                <p>For companies looking to compete beyond their home market, our IT strategy consulting helps lay the groundwork for a serious digital presence. We also work closely with organizations going through bigger structural shifts â€” implementing ERP systems, managing change across teams, and building the kind of internal frameworks that make growth sustainable rather than chaotic.</p>
                <p>What we care about most, honestly, is fit. Technology that clashes with how your people actually work tends to fail quietly and expensively. So we take the time to understand your culture and your long-term direction before recommending anything. And when the opportunity is there, we don't just upgrade what exists â€” we help you think about entirely new ways to grow.</p>
                <p>If you're looking for an IT partner who thinks a few steps ahead, you're in the right place.</p>
              </div>
            </details>
          </article>
          <article class="card reveal">
            <div class="chip">BUS</div>
            <h3>Business Consulting</h3>
            <p>Strategic guidance to build resilient, high-performing organizations.</p>
            <details class="read-more">
              <summary>Read more</summary>
              <div class="read-more-content">
                <p>Every business hits walls. Sometimes it's a growth phase that feels impossible to manage, sometimes it's a market shift that nobody saw coming, and sometimes it's simply not knowing which direction to move next. At iTech Global, we've built our consulting practice around exactly these moments â€” because the right advice at the right time genuinely changes outcomes.</p>
                <p>We work with all kinds of organizations, from companies that have been around for decades and need to stay relevant, to startups that are still finding their footing and trying to carve out space in a crowded market. The challenges are different, but the need is the same â€” someone in your corner who knows what they're talking about and isn't afraid to tell you what you actually need to hear.</p>
                <p>Our consultants bring real depth to the table. Whether you're figuring out how to allocate capital wisely, exploring a new market, or trying to scale without losing control of your operations, we work through it with you â€” not just hand you a report and walk away. We stay close to what's happening in markets, track where technology is headed, and use all of that to help you make sharper decisions.</p>
                <p>Think of it a bit like having a coach. Not someone who takes over, but someone who helps you see the full picture, spot what you might be missing, and build a game plan that actually fits your situation. We're direct, practical, and focused on results that you can measure.</p>
                <p>The areas we cover are broad â€” investment planning, R&amp;D, hiring and talent strategy, workforce development, business transformation, and long-term stability. But in every engagement, the goal is the same: to leave your organization stronger, sharper, and better prepared for whatever comes next.</p>
                <p>If you want a team that's genuinely invested in where your business is headed, iTech Global is ready to get to work.</p>
              </div>
            </details>
          </article>
        </div>
      </div>
    </section>

    <section id="technology" class="section">
      <div class="container">
        <header class="section-head reveal">
          <span class="eyebrow">Technology</span>
          <h2>Technology &amp; IT Consulting Solutions</h2>
          <p>We help organizations streamline operations and accelerate digital transformation through advanced integration technologies, enterprise automation, web development, and scalable IT consulting solutions tailored to modern business needs.</p>
        </header>
        <?php
          $technology_items = array(
            array('title' => 'EDI (Electronic Data Interchange)', 'description' => 'Automated document exchange that improves partner compliance, accuracy, and transaction speed.', 'icon' => 'exchange'),
            array('title' => 'API Integration', 'description' => 'Secure API connectivity between applications, platforms, vendors, and customer-facing systems.', 'icon' => 'api'),
            array('title' => 'EDI/API Integration', 'description' => 'Hybrid integration models that connect traditional EDI networks with modern API workflows.', 'icon' => 'network'),
            array('title' => 'B2B Gateway', 'description' => 'Centralized trading partner communication, routing, validation, and operational visibility.', 'icon' => 'gateway'),
            array('title' => 'Managed File Transfer (MFT)', 'description' => 'Reliable file movement with security, audit trails, scheduling, and exception handling.', 'icon' => 'file'),
            array('title' => 'Supplier Portal', 'description' => 'Self-service supplier workflows for onboarding, documents, orders, and status tracking.', 'icon' => 'portal'),
            array('title' => 'B2B eCommerce Solutions', 'description' => 'Digital commerce experiences built for partner ordering, account workflows, and scale.', 'icon' => 'cart'),
            array('title' => 'VAN EDI', 'description' => 'Value-added network connectivity for dependable EDI communication and partner reach.', 'icon' => 'cloud'),
            array('title' => 'Web EDI', 'description' => 'Browser-based EDI tools for partners that need simple, accessible transaction processing.', 'icon' => 'browser'),
            array('title' => 'Web Development', 'description' => 'Responsive websites and web applications built for performance, usability, and maintainability.', 'icon' => 'code'),
            array('title' => 'Cloud Integration', 'description' => 'Cloud-first connectivity across SaaS, data platforms, infrastructure, and enterprise systems.', 'icon' => 'cloud'),
            array('title' => 'Enterprise Application Integration', 'description' => 'Connected enterprise workflows across business-critical applications and data sources.', 'icon' => 'apps'),
            array('title' => 'ERP Integration', 'description' => 'ERP-aligned integrations for orders, inventory, invoices, master data, and reporting.', 'icon' => 'database'),
            array('title' => 'System Automation', 'description' => 'Workflow automation that reduces manual effort, improves reliability, and speeds execution.', 'icon' => 'automation'),
            array('title' => 'Digital Transformation Solutions', 'description' => 'Practical modernization roadmaps that turn legacy processes into scalable digital operations.', 'icon' => 'spark'),
            array('title' => 'Data Integration &amp; Migration', 'description' => 'Clean, governed data movement across platforms, formats, databases, and business systems.', 'icon' => 'data'),
            array('title' => 'Business Process Automation', 'description' => 'Automation programs that standardize approvals, handoffs, alerts, and operational tasks.', 'icon' => 'workflow'),
            array('title' => 'Microservices Architecture', 'description' => 'Modular service architectures designed for resilience, independent scaling, and maintainable change.', 'icon' => 'services'),
            array('title' => 'SaaS Integration', 'description' => 'Integration of SaaS tools into enterprise workflows, reporting systems, and data pipelines.', 'icon' => 'saas'),
            array('title' => 'Custom Software Development', 'description' => 'Purpose-built software that supports unique operations, integrations, and customer experiences.', 'icon' => 'custom'),
          );
        ?>
        <div class="tech-grid">
          <?php foreach ($technology_items as $item) : ?>
            <article class="tech-card reveal">
              <span class="tech-icon"><?php echo itechglobal_tech_icon($item['icon']); ?></span>
              <h3><?php echo wp_kses_post($item['title']); ?></h3>
              <p><?php echo esc_html($item['description']); ?></p>
            </article>
          <?php endforeach; ?>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container stripe reveal">
        <div><h3>Executive visibility</h3><p>Weekly reporting, risk tracking, and clear milestones.</p></div>
        <div><h3>Operational certainty</h3><p>SLAs, monitoring, and escalation plans built in.</p></div>
        <div><h3>Scalable delivery</h3><p>Reusable frameworks that shorten delivery timelines.</p></div>
      </div>
    </section>

    <section id="work" class="section">
      <div class="container">
        <header class="section-head reveal">
          <span class="eyebrow">Focus Areas</span>
          <h2>What we help you deliver.</h2>
          <p>We build reliable, scalable systems with clear business outcomes in mind.</p>
        </header>
        <div class="grid3">
          <article class="case reveal">
            <img loading="lazy" decoding="async" width="800" height="420" alt="EDI integration workflow visualization" src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='420' viewBox='0 0 800 420'><defs><linearGradient id='g2' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='%231a3a5e'/><stop offset='100%' stop-color='%232bb4f1'/></linearGradient></defs><rect width='800' height='420' fill='url(%23g2)'/><g fill='none' stroke='%23e7f0ff' stroke-width='2' opacity='0.6'><circle cx='140' cy='140' r='60'/><circle cx='380' cy='220' r='80'/><circle cx='620' cy='140' r='55'/><path d='M200 150 L300 200 L460 220 L560 170'/></g></svg>">
            <div class="case-body"><h3>EDI onboarding & compliance</h3><p>Streamlined partner setup, mapping, and monitoring workflows.</p></div>
          </article>
          <article class="case reveal">
            <img loading="lazy" decoding="async" width="800" height="420" alt="Cloud modernization skyline" src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='420' viewBox='0 0 800 420'><defs><linearGradient id='g3' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='%2314324f'/><stop offset='100%' stop-color='%236bd6ff'/></linearGradient></defs><rect width='800' height='420' fill='url(%23g3)'/><g fill='%23e7f0ff' opacity='0.25'><rect x='120' y='180' width='80' height='160'/><rect x='230' y='140' width='110' height='200'/><rect x='370' y='200' width='90' height='140'/><rect x='490' y='160' width='120' height='180'/></g></svg>">
            <div class="case-body"><h3>Cloud modernization</h3><p>Migration planning, performance tuning, and cost visibility.</p></div>
          </article>
          <article class="case reveal">
            <img loading="lazy" decoding="async" width="800" height="420" alt="Product engineering blueprint" src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='420' viewBox='0 0 800 420'><defs><linearGradient id='g4' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='%230f1f33'/><stop offset='100%' stop-color='%2300d2c7'/></linearGradient></defs><rect width='800' height='420' fill='url(%23g4)'/><g stroke='%23e7f0ff' stroke-width='2' fill='none' opacity='0.6'><rect x='110' y='110' width='220' height='160' rx='12'/><rect x='370' y='140' width='320' height='200' rx='12'/><path d='M180 290 L420 290'/></g></svg>">
            <div class="case-body"><h3>Product engineering</h3><p>MVP planning, UX delivery, and production readiness.</p></div>
          </article>
        </div>
      </div>
    </section>

    <section id="process" class="section">
      <div class="container">
        <header class="section-head reveal">
          <span class="eyebrow">Process</span>
          <h2>Structured delivery from discovery to launch.</h2>
          <p>Clarity at every step with shared ownership and measurable milestones.</p>
        </header>
        <div class="timeline">
          <div class="step reveal"><span>01</span><h3>Discovery</h3><p>Stakeholder interviews and system review.</p></div>
          <div class="step reveal"><span>02</span><h3>Blueprint</h3><p>Architecture, integration maps, and plan.</p></div>
          <div class="step reveal"><span>03</span><h3>Build</h3><p>Agile delivery with weekly demos.</p></div>
          <div class="step reveal"><span>04</span><h3>Launch</h3><p>Cutover planning and ongoing support.</p></div>
        </div>
      </div>
    </section>

    <section id="about" class="section">
      <div class="container">
        <header class="section-head reveal">
          <span class="eyebrow">About</span>
          <h2>New team. Senior experience. Long-term mindset.</h2>
          <p>We are a new company built by experienced engineers and consultants focused on quality delivery.</p>
        </header>
        <div class="grid3">
          <article class="card reveal"><h3>Senior-led delivery</h3><p>Hands-on leadership with clear communication and accountability.</p></article>
          <article class="card reveal"><h3>Quality-first engineering</h3><p>Secure, maintainable, and well-documented implementations.</p></article>
          <article class="card reveal"><h3>Partnership mindset</h3><p>Flexible support and continuous improvement after launch.</p></article>
        </div>
      </div>
    </section>

    <section id="faq" class="section">
      <div class="container">
        <header class="section-head reveal">
          <span class="eyebrow">FAQ</span>
          <h2>Answers to common questions.</h2>
          <p>Quick clarity before you get started.</p>
        </header>
        <div class="faq">
          <div class="faq-item reveal">
            <button class="q" type="button" aria-expanded="false">How long does a typical project take? <span aria-hidden="true">+</span></button>
            <div class="a"><p>Most projects launch in 4 to 10 weeks depending on integration scope.</p></div>
          </div>
          <div class="faq-item reveal">
            <button class="q" type="button" aria-expanded="false">Do you support existing vendors? <span aria-hidden="true">+</span></button>
            <div class="a"><p>Yes, we integrate with ERPs, WMS, and trading partners using proven frameworks.</p></div>
          </div>
          <div class="faq-item reveal">
            <button class="q" type="button" aria-expanded="false">What happens after launch? <span aria-hidden="true">+</span></button>
            <div class="a"><p>We provide monitoring, SLAs, and enhancement sprints.</p></div>
          </div>
        </div>
      </div>
    </section>

    <section id="contact" class="section">
      <div class="container contact reveal">
        <aside class="contact-info">
          <h2>Let us design your next release</h2>
          <p>Email: info@itechglobal.in</p>
          <div class="contact-image">
            <img loading="lazy" decoding="async" width="800" height="360" alt="Global operations map" src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='360' viewBox='0 0 800 360'><defs><linearGradient id='g5' x1='0' y1='0' x2='1' y2='1'><stop offset='0%' stop-color='%230d2a4a'/><stop offset='100%' stop-color='%232bb4f1'/></linearGradient></defs><rect width='800' height='360' fill='url(%23g5)'/><g fill='none' stroke='%23e7f0ff' stroke-width='1.6' opacity='0.5'><ellipse cx='400' cy='180' rx='220' ry='90'/><ellipse cx='400' cy='180' rx='140' ry='60'/><path d='M180 180 H620'/><path d='M400 90 V270'/></g></svg>">
          </div>
        </aside>
        <form id="itechglobal-contact-form" class="contact-form itechglobal-contact-form" method="POST" novalidate>
          <div class="row">
            <div class="field"><label for="name">Full Name</label><input id="name" name="name" type="text" required></div>
            <div class="field"><label for="email">Work Email</label><input id="email" name="email" type="email" required></div>
          </div>
          <div class="field"><label for="subject">Subject</label><input id="subject" name="subject" type="text" required></div>
          <div class="field"><label for="message">Project Details</label><textarea id="message" name="message" rows="4" required></textarea></div>
          <?php wp_nonce_field('itechglobal_contact_form_nonce', 'nonce', false); ?>
          <button class="btn primary" type="submit">Send Message</button>
          <span class="form-loading">Sending...</span>
          <div class="form-message" aria-live="polite"></div>
        </form>
      </div>
    </section>
  </main>
