<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="<?php echo esc_url(get_template_directory_uri()); ?>/assets/itech-mark.png">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
    <div class="logo-strip-full">
      <div class="container nav">
        <a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/itech-logo.png" alt="iTech Global logo"></a>
        <button class="menu-btn" type="button" aria-expanded="false" aria-controls="main-nav">Menu</button>
        <nav id="main-nav" class="nav-links" aria-label="Main navigation">
          <a href="<?php echo esc_url(home_url('/#services')); ?>">Services</a>
          <a href="<?php echo esc_url(home_url('/#technology')); ?>">Technology</a>
          <a href="<?php echo esc_url(home_url('/#work')); ?>">Work</a>
          <a href="<?php echo esc_url(home_url('/#process')); ?>">Process</a>
          <a href="<?php echo esc_url(home_url('/#about')); ?>">About</a>
          <a href="<?php echo esc_url(home_url('/#faq')); ?>">FAQ</a>
          <a class="nav-cta" href="<?php echo esc_url(home_url('/#contact')); ?>">Start Project</a>
        </nav>
      </div>
    </div>
  </header>
